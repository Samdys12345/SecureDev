package com.example.hospimanagmenetapp.encryption;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.nio.ByteBuffer;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class AesGcmKeystoreEncryptor {

    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int GCM_TAG_LENGTH = 128; // bits
    private static final int IV_LENGTH = 12; // bytes (recommended for GCM)

    private final String alias;

    public AesGcmKeystoreEncryptor() throws Exception {
        this.alias = "hms_aes_key";
        createKeyIfNeeded();
    }

    private void createKeyIfNeeded() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (!ks.containsAlias(alias)) {
            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM, KEYSTORE);
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    alias,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
            )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build();
            keyGenerator.init(spec);
            keyGenerator.generateKey();
        }
    }

    private SecretKey getSecretKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        return ((SecretKey) ks.getKey(alias, null));
    }

    public byte[] encrypt(byte[] plaintext) throws Exception {
        SecretKey key = getSecretKey();

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);

        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] ciphertext = cipher.doFinal(plaintext);
        byte[] iv = cipher.getIV();

        ByteBuffer bb = ByteBuffer.allocate(iv.length + ciphertext.length);
        bb.put(iv);
        bb.put(ciphertext);
        return bb.array();
    }

    public byte[] decrypt(byte[] ivAndCiphertext) throws Exception {
        if (ivAndCiphertext == null || ivAndCiphertext.length < IV_LENGTH) {
            throw new IllegalArgumentException("Invalid input to decrypt");
        }

        ByteBuffer bb = ByteBuffer.wrap(ivAndCiphertext);
        byte[] iv = new byte[IV_LENGTH];
        bb.get(iv);
        byte[] ciphertext = new byte[bb.remaining()];
        bb.get(ciphertext);

        SecretKey key = getSecretKey();

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.DECRYPT_MODE, key, spec);

        return cipher.doFinal(ciphertext);
    }
}
