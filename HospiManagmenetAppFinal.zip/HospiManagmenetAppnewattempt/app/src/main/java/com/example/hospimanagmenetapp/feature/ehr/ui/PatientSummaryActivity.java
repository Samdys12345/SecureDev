package com.example.hospimanagmenetapp.feature.ehr.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.ClinicalRecord;
import com.example.hospimanagmenetapp.encryption.hashing.Hash;

import java.util.concurrent.Executors;

public class PatientSummaryActivity extends AppCompatActivity {


    private EditText etNhsInput;
    private Button btnSubmitNhs;
    private Button btnRecordVitals;
    private TextView tvProblems, tvAllergies, tvMedications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_summary);

        // Bind UI
        etNhsInput = findViewById(R.id.etNhsInput);
        btnSubmitNhs = findViewById(R.id.btnSubmitNhs);
        btnRecordVitals = findViewById(R.id.btnRecordVitals); // Make sure this ID exists in XML
        tvProblems = findViewById(R.id.tvProblems);
        tvAllergies = findViewById(R.id.tvAllergies);
        tvMedications = findViewById(R.id.tvMedications);

        // NHS submit button
        btnSubmitNhs.setOnClickListener(v -> {
            String nhs = etNhsInput.getText().toString().trim();
            if (nhs.isEmpty()) {
                Toast.makeText(this, "Enter NHS number", Toast.LENGTH_SHORT).show();
                return;
            }

            String hashedNhs;
            try {
                hashedNhs = Hash.hashToHex(nhs);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error hashing NHS number", Toast.LENGTH_SHORT).show();
                return;
            }

            Executors.newSingleThreadExecutor().execute(() -> {
                int count = AppDatabase.getInstance(getApplicationContext())
                        .patientDao().countByNhs(hashedNhs);

                if (count > 0) {
                    ClinicalRecord record = AppDatabase.getInstance(getApplicationContext())
                            .clinicalRecordDao().findByPatient(hashedNhs);

                    runOnUiThread(() -> {
                        if (record != null) {
                            tvProblems.setText("Problems: " + record.problems);
                            tvAllergies.setText("Allergies: " + record.allergies);
                            tvMedications.setText("Medications: " + record.medications);
                        } else {
                            tvProblems.setText("No clinical record found.");
                            tvAllergies.setText("");
                            tvMedications.setText("");
                        }
                    });
                } else {
                    runOnUiThread(() -> {
                        Toast.makeText(this, "NHS number not found", Toast.LENGTH_LONG).show();
                        tvProblems.setText("");
                        tvAllergies.setText("");
                        tvMedications.setText("");
                    });
                }
            });
        });

        // Vitals button — independent of NHS number
        btnRecordVitals.setOnClickListener(view -> {
            Intent intent = new Intent(this, VitalsActivity.class);
            startActivity(intent);
        });
    }


}
