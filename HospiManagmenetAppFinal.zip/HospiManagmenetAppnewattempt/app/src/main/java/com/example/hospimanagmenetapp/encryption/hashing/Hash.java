package com.example.hospimanagmenetapp.encryption.hashing;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Hash {

    private static final String ALGORITHM = "SHA-256";

    public static byte[] hash(String input) throws NoSuchAlgorithmException {
        if (input == null) throw new IllegalArgumentException("Input cannot be null");

        MessageDigest digest = MessageDigest.getInstance(ALGORITHM);
        return digest.digest(input.getBytes());
    }

    public static String hashToHex(String input) throws NoSuchAlgorithmException {
        byte[] hashedBytes = hash(input);
        return toHex(hashedBytes);
    }

    public static String toHex(byte[] bytes) {
        if (bytes == null) return null;
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b & 0xff));
        }
        return sb.toString();
    }
}
