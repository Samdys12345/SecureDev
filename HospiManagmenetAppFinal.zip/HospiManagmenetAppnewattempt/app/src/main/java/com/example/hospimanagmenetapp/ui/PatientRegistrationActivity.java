package com.example.hospimanagmenetapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.Patient;
import com.example.hospimanagmenetapp.encryption.AesGcmKeystoreEncryptor;
import com.example.hospimanagmenetapp.encryption.hashing.Hash;
import com.example.hospimanagmenetapp.util.ValidationUtils;

import java.util.concurrent.Executors;

public class PatientRegistrationActivity extends AppCompatActivity {


    private EditText etNhs, etFullName, etDob, etPhone, etEmail;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_registration);

        etNhs = findViewById(R.id.etNhs);
        etFullName = findViewById(R.id.etFullName);
        etDob = findViewById(R.id.etDob);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        btnSave = findViewById(R.id.btnSavePatient);

        btnSave.setOnClickListener(v -> savePatient());
    }

    private void savePatient() {
        String nhs = etNhs.getText().toString().trim();
        String fullName = etFullName.getText().toString().trim();
        String dob = etDob.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        if (TextUtils.isEmpty(nhs) || TextUtils.isEmpty(fullName) || TextUtils.isEmpty(dob)) {
            Toast.makeText(this, "NHS number, name, and DOB are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ValidationUtils.validateNhsNumber(nhs)) {
            Toast.makeText(this, "Invalid NHS number.", Toast.LENGTH_SHORT).show();
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                AppDatabase db = AppDatabase.getInstance(getApplicationContext());

                String hashedNhs = Hash.hashToHex(nhs); // <-- hash NHS number here

                if (db.patientDao().countByNhs(hashedNhs) > 0) {
                    runOnUiThread(() -> Toast.makeText(this, "Patient with this NHS number already exists.", Toast.LENGTH_SHORT).show());
                    return;
                }

                AesGcmKeystoreEncryptor encryptor = new AesGcmKeystoreEncryptor();

                Patient p = new Patient();
                p.nhsNumber = hashedNhs; // <-- store the hash
                p.fullNameEnc = encryptor.encrypt(fullName.getBytes());
                p.dateOfBirthEnc = encryptor.encrypt(dob.getBytes());
                p.phoneEnc = encryptor.encrypt(phone.getBytes());
                p.emailEnc = encryptor.encrypt(email.getBytes());

                long now = System.currentTimeMillis();
                p.createdAt = now;
                p.updatedAt = now;

                db.patientDao().insert(p);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Patient saved.", Toast.LENGTH_SHORT).show();
                    finish();
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Error saving patient.", Toast.LENGTH_SHORT).show());
            }
        });
    }


}
