package com.example.hospimanagmenetapp.network.dto;

public class AppointmentDto {
    public long id;
    public String patientNhsNumber;
    public long startTime;
    public long endTime;
    public long clinicianId;
    public String clinicianName;
    public String clinic;
    public String status;
}