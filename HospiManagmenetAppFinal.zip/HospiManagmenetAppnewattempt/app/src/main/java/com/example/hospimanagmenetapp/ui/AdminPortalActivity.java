package com.example.hospimanagmenetapp.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.dao.StaffDao;
import com.example.hospimanagmenetapp.data.entities.Staff;
import com.example.hospimanagmenetapp.encryption.AesGcmKeystoreEncryptor;
import com.example.hospimanagmenetapp.ui.adapters.StaffAdapter;
import com.example.hospimanagmenetapp.util.SessionManager;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;

public class AdminPortalActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPin;
    private Spinner spRole;
    private Button btnRegisterStaff, btnRefresh;
    private RecyclerView rvStaff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_portal);

        etName = findViewById(R.id.etStaffName);
        etEmail = findViewById(R.id.etStaffEmail);
        etPin = findViewById(R.id.etAdminSetupPin);
        spRole = findViewById(R.id.spRole);
        btnRegisterStaff = findViewById(R.id.btnRegisterStaff);
        btnRefresh = findViewById(R.id.btnRefreshList);
        rvStaff = findViewById(R.id.rvStaff);

        rvStaff.setLayoutManager(new LinearLayoutManager(this));

        spRole.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                Arrays.asList(Staff.Role.values())
        ));

        btnRegisterStaff.setOnClickListener(v -> registerStaff());
        btnRefresh.setOnClickListener(v -> loadStaff());

        boolean bypass = getIntent().getBooleanExtra("bypassCheck", false);
        if (!bypass) {
            String role = SessionManager.getCurrentRole(this);
            if (!"ADMIN".equals(role)) {
                Toast.makeText(this, "Admin access required.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }

        loadStaff();
    }

    private void registerStaff() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        Staff.Role role = (Staff.Role) spRole.getSelectedItem();
        String pin = etPin.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Name and email are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (role == Staff.Role.ADMIN && TextUtils.isEmpty(pin)) {
            Toast.makeText(this, "Admin PIN is required for ADMIN role.", Toast.LENGTH_SHORT).show();
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                AesGcmKeystoreEncryptor encryptor = new AesGcmKeystoreEncryptor();
                StaffDao dao = AppDatabase.getInstance(getApplicationContext()).staffDao();

                Staff s = new Staff();
                s.role = role;
                s.fullName = encryptor.encrypt(name.getBytes(StandardCharsets.UTF_8));
                s.email = encryptor.encrypt(email.getBytes(StandardCharsets.UTF_8));
                s.emailHash = hash(email);
                s.adminPin = (role == Staff.Role.ADMIN) ? encryptor.encrypt(pin.getBytes(StandardCharsets.UTF_8)) : null;

                dao.insert(s);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Staff registered.", Toast.LENGTH_SHORT).show();
                    etName.setText("");
                    etEmail.setText("");
                    etPin.setText("");
                    loadStaff();
                });

            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, "Error: email may already exist.", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void loadStaff() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                AesGcmKeystoreEncryptor encryptor = new AesGcmKeystoreEncryptor();
                List<Staff> staffList = AppDatabase.getInstance(getApplicationContext()).staffDao().getAll();

                // Decrypt fields in-place before passing to adapter
                for (Staff s : staffList) {
                    s.fullName = encryptor.decrypt(s.fullName);
                    s.email = encryptor.decrypt(s.email);
                    if (s.adminPin != null) {
                        s.adminPin = encryptor.decrypt(s.adminPin);
                    }
                }

                runOnUiThread(() -> rvStaff.setAdapter(new StaffAdapter(staffList)));

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private String hash(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashed = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        return android.util.Base64.encodeToString(hashed, android.util.Base64.NO_WRAP);
    }
}
