package com.example.hospimanagmenetapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.Staff;
import com.example.hospimanagmenetapp.encryption.AesGcmKeystoreEncryptor;
import com.example.hospimanagmenetapp.util.SessionManager;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.Executors;

public class AdminLoginActivity extends AppCompatActivity {

    private EditText etEmail, etPin;
    private Button btnLogin, btnOpenSetup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        etEmail = findViewById(R.id.etAdminEmail);
        etPin = findViewById(R.id.etAdminPin);
        btnLogin = findViewById(R.id.btnAdminLogin);
        btnOpenSetup = findViewById(R.id.btnOpenAdminSetup);

        btnLogin.setOnClickListener(v -> doLogin());
        btnOpenSetup.setOnClickListener(v -> openAdminPortal());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Enable setup button if no ADMIN exists
        Executors.newSingleThreadExecutor().execute(() -> {
            int admins = AppDatabase.getInstance(getApplicationContext())
                    .staffDao().countAdmins();
            runOnUiThread(() -> btnOpenSetup.setEnabled(admins == 0));
        });
    }

    private void openAdminPortal() {
        Intent i = new Intent(this, AdminPortalActivity.class);
        i.putExtra("bypassCheck", true); // allow first-time bootstrap
        startActivity(i);
        finish();
    }

    private void doLogin() {
        String emailInput = etEmail.getText().toString().trim();
        String pinInput = etPin.getText().toString().trim();

        if (TextUtils.isEmpty(emailInput) || TextUtils.isEmpty(pinInput)) {
            Toast.makeText(this, "Email and PIN are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                AesGcmKeystoreEncryptor encryptor = new AesGcmKeystoreEncryptor();

                // Compute hash for lookup
                String emailHash = hash(emailInput);

                Staff s = AppDatabase.getInstance(getApplicationContext())
                        .staffDao()
                        .findByEmailHash(emailHash);

                if (s == null || s.role != Staff.Role.ADMIN || s.adminPin == null) {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Invalid admin credentials.", Toast.LENGTH_SHORT).show());
                    return;
                }

                // Decrypt stored PIN
                String decryptedPin = new String(encryptor.decrypt(s.adminPin), StandardCharsets.UTF_8);

                if (!pinInput.equals(decryptedPin)) {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Invalid admin credentials.", Toast.LENGTH_SHORT).show());
                    return;
                }

                // Success: decrypt email for session
                String decryptedEmail = new String(encryptor.decrypt(s.email), StandardCharsets.UTF_8);
                SessionManager.setCurrentUser(this, "ADMIN", decryptedEmail);

                runOnUiThread(() -> {
                    startActivity(new Intent(this, AdminPortalActivity.class));
                    finish();
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(this, "Login error occurred.", Toast.LENGTH_SHORT).show());
            }
        });
    }

    // Compute SHA-256 hash of email for lookup
    private String hash(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashed = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        return android.util.Base64.encodeToString(hashed, android.util.Base64.NO_WRAP);
    }
}
