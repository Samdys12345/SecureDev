package com.example.hospimanagmenetapp.feature.ehr.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.Vitals;
import com.example.hospimanagmenetapp.encryption.AesGcmKeystoreEncryptor;
import com.example.hospimanagmenetapp.encryption.hashing.Hash;
import java.util.concurrent.Executors;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class VitalsActivity extends AppCompatActivity {

    private EditText etNhs, etTemp, etHeart, etSys, etDia;
    private Button btnSaveVitals;
    private AesGcmKeystoreEncryptor encryptor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vitals);
        etNhs = findViewById(R.id.etNhs);
        etTemp = findViewById(R.id.etTemp);
        etHeart = findViewById(R.id.etHeart);
        etSys = findViewById(R.id.etSys);
        etDia = findViewById(R.id.etDia);
        btnSaveVitals = findViewById(R.id.btnSaveVitals);

        try {
            encryptor = new AesGcmKeystoreEncryptor();
        } catch (Exception e) {
            Toast.makeText(this, "Security initialization failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            btnSaveVitals.setEnabled(false);
            e.printStackTrace();
        }

        btnSaveVitals.setOnClickListener(v -> saveVitals());
    }

    private void saveVitals() {
        final String nhs = etNhs.getText().toString().trim();
        final String temp = etTemp.getText().toString().trim();
        final String heart = etHeart.getText().toString().trim();
        final String sys = etSys.getText().toString().trim();
        final String dia = etDia.getText().toString().trim();

        if (TextUtils.isEmpty(nhs) || TextUtils.isEmpty(temp) || TextUtils.isEmpty(heart) || TextUtils.isEmpty(sys) || TextUtils.isEmpty(dia)) {
            Toast.makeText(this, "All fields are required. Please try again.", Toast.LENGTH_SHORT).show();
            return;
        }

        final byte[] nhsBytes = nhs.getBytes(StandardCharsets.UTF_8);
        final byte[] tempBytes = temp.getBytes(StandardCharsets.UTF_8);
        final byte[] heartBytes = heart.getBytes(StandardCharsets.UTF_8);
        final byte[] sysBytes = sys.getBytes(StandardCharsets.UTF_8);
        final byte[] diaBytes = dia.getBytes(StandardCharsets.UTF_8);

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                byte[] nhsEncrypted = encryptor.encrypt(nhsBytes);
                byte[] tempEncrypted = encryptor.encrypt(tempBytes);
                byte[] heartEncrypted = encryptor.encrypt(heartBytes);
                byte[] sysEncrypted = encryptor.encrypt(sysBytes);
                byte[] diaEncrypted = encryptor.encrypt(diaBytes);

                if (nhsEncrypted == null || tempEncrypted == null || heartEncrypted == null) {
                    throw new RuntimeException("Encryption failed to produce valid output.");
                }

                AppDatabase db = AppDatabase.getInstance(getApplicationContext());

                String hashed = Hash.hashToHex(nhs);
                // Ensure patient exists in *patient* table
                if (db.patientDao().countByNhs(hashed) == 0) {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Patient with this NHS number does not exist.", Toast.LENGTH_SHORT).show());
                    return;
                }

                // Delete any existing vitals rows that belong to this NHS.
                List<Vitals> all = db.vitalsDao().getAll();
                if (all != null && !all.isEmpty()) {
                    for (Vitals existing : all) {
                        try {
                            if (existing.patientNhsEncrypted == null) continue;
                            byte[] decrypted = encryptor.decrypt(existing.patientNhsEncrypted);
                            if (decrypted == null) continue;
                            String existingNhs = new String(decrypted, StandardCharsets.UTF_8);
                            if (nhs.equals(existingNhs)) {
                                db.vitalsDao().deleteById(existing.id);
                            }
                        } catch (Exception exDecryptRow) {
                            // If a particular row can't be decrypted, skip it but log for debugging
                            exDecryptRow.printStackTrace();
                        }
                    }
                }

                // Map inputs to a new Vitals entity (store encrypted NHS)
                Vitals v = new Vitals();
                v.patientNhsEncrypted = nhsEncrypted;
                v.temperatureEncrypted = tempEncrypted;
                v.heartRateEncrypted = heartEncrypted;
                v.systolicEncrypted = sysEncrypted;
                v.diastolicEncrypted = diaEncrypted;
                v.timestamp = System.currentTimeMillis();
                v.synced = false;

                db.vitalsDao().insert(v);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Vitals saved and encrypted.", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(this, "Error saving Vitals. Check logs.", Toast.LENGTH_SHORT).show());
            }
        });
    }
}
