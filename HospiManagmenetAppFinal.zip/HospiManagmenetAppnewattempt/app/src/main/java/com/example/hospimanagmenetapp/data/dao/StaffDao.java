package com.example.hospimanagmenetapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.hospimanagmenetapp.data.entities.Staff;

import java.util.List;

@Dao
public interface StaffDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(Staff staff);

    @Query("SELECT * FROM staff ORDER BY fullName ASC")
    List<Staff> getAll();

    @Query("SELECT COUNT(*) FROM staff WHERE role = 'ADMIN'")
    int countAdmins();

    @Query("SELECT * FROM staff WHERE emailHash = :hash LIMIT 1")
    Staff findByEmailHash(String hash); // Lookup by hash
}

