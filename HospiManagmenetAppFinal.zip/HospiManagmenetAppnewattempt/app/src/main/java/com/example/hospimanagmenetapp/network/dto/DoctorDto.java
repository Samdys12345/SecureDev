package com.example.hospimanagmenetapp.network.dto;

public class DoctorDto {
    public long id;
    public String name;
    public String clinic;
}