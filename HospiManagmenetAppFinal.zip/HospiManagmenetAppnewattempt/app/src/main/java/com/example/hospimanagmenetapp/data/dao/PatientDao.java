package com.example.hospimanagmenetapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.hospimanagmenetapp.data.entities.Patient;

@Dao
public interface PatientDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(Patient patient);

    @Query("SELECT COUNT(*) FROM patients WHERE nhsNumber = :nhsNumber")
    int countByNhs(String nhsNumber);
}

