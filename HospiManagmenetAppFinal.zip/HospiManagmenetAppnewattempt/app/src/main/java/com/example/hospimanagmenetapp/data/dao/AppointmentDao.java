package com.example.hospimanagmenetapp.data.dao;

import androidx.annotation.Nullable;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.hospimanagmenetapp.data.entities.Appointment;

import java.util.List;

@Dao
public interface AppointmentDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(Appointment appt);

    @Update
    int update(Appointment appt);

    @Query("SELECT * FROM appointments WHERE startTime BETWEEN :start AND :end ORDER BY startTime ASC")
    List<Appointment> findBetween(long start, long end);

    @Query("SELECT * FROM appointments WHERE clinicianId = :clinicianId AND "
            + "( (startTime < :newEnd AND endTime > :newStart) )")
    List<Appointment> overlapping(long clinicianId, long newStart, long newEnd);

    @Query("SELECT * FROM appointments WHERE id = :id LIMIT 1")
    Appointment findById(long id);

    @Query("SELECT * FROM appointments " +
            "WHERE startTime BETWEEN :start AND :end " +
            "AND (:clinic IS NULL OR clinic = :clinic) " +
            "ORDER BY startTime ASC")
    List<Appointment> findBetweenOptionalClinic(long start, long end, String clinic);

    @Query("DELETE FROM appointments WHERE endTime < :ts")
    void deleteBefore(long ts);

    @Query("DELETE FROM appointments WHERE startTime >= :start AND startTime < :end")
    void deleteBetween(long start, long end);

    @Query("DELETE FROM appointments")
    void deleteAll();


    @Query("SELECT * FROM appointments " +
            "WHERE clinicianId = :clinicianId " +
            "AND status = 'BOOKED' " +
            "AND (:start < endTime AND :end > startTime)")
    List<Appointment> getConflictingAppointments(long clinicianId, long start, long end);

    @Query("SELECT COUNT(*) FROM appointments " +
            "WHERE clinicianId = :clinicianId " +
            "AND (:excludeId IS NULL OR id != :excludeId) " +
            "AND status = 'BOOKED' " +
            "AND (startTime < :end AND endTime > :start)")
    int countConflicts(long clinicianId, long start, long end, Long excludeId);

    @Query("SELECT * FROM appointments " +
            "WHERE clinicianId = :clinicianId " +
            "AND startTime = :start " +
            "AND endTime = :end " +
            "AND status = 'FREE' " +
            "LIMIT 1")
    Appointment findFreeSlot(long clinicianId, long start, long end);




}

