package com.example.hospimanagmenetapp.data.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "vitals")
public class Vitals {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    public byte[] patientNhsEncrypted;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    public byte[] temperatureEncrypted;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    public byte[] heartRateEncrypted;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    public byte[] systolicEncrypted;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    public byte[] diastolicEncrypted;

    public long timestamp;
    public boolean synced;
}
