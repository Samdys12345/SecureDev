package com.example.hospimanagmenetapp.feature.appointments.ui;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.dao.AppointmentDao;
import com.example.hospimanagmenetapp.data.entities.Appointment;

import java.util.Calendar;

public class DailyAppointmentWorker extends Worker {

    public DailyAppointmentWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        AppointmentDao dao = AppDatabase.getInstance(getApplicationContext()).appointmentDao();
        dao.deleteAll();

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 9);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        long slotDuration = 3600000; // 1 hour
        String[] clinics = {"Surgery A", "Surgery B"};

        for (int clinicianId = 1; clinicianId <= clinics.length; clinicianId++) {
            long startTime = cal.getTimeInMillis();
            for (int i = 0; i < 8; i++) { // 8 slots per clinician
                Appointment a = new Appointment();
                a.clinicianId = clinicianId;
                a.clinicianName = "Dr. " + clinicianId;
                a.clinic = clinics[clinicianId - 1];
                a.startTime = startTime + (i * slotDuration);
                a.endTime = startTime + ((i + 1) * slotDuration);
                a.status = "FREE"; // or "BOOKED" if desired
                dao.insert(a);
            }
        }

        return Result.success();
    }
}
