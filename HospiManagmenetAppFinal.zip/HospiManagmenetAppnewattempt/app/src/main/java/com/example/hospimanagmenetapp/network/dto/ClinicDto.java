package com.example.hospimanagmenetapp.network.dto;

public class ClinicDto {
    public String name;
    public String location;
}