// AppointmentRepository.java
package com.example.hospimanagmenetapp.data.repo;

import android.content.Context;
import android.util.Log;

import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.dao.AppointmentDao;
import com.example.hospimanagmenetapp.data.entities.Appointment;
import com.example.hospimanagmenetapp.network.ApiClient;
import com.example.hospimanagmenetapp.network.dto.AppointmentDto;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Response;

public class AppointmentRepository {

    private final AppointmentDao dao;
    private final ApiClient api;

    public AppointmentRepository(Context ctx) {
        this.dao = AppDatabase.getInstance(ctx).appointmentDao();
        this.api = new ApiClient(ctx);
    }

    public Appointment findFreeSlot(long clinicianId, long start, long end) {
        return dao.findFreeSlot(clinicianId, start, end);
    }

    public List<Appointment> getTodaysAppointments(String clinic, long start, long end) throws Exception {
        Log.d("REPO", "==== getTodaysAppointments() CALLED ====");
        Log.d("REPO", "clinic = [" + clinic + "]");
        Log.d("REPO", "Start of day millis = " + start);
        Log.d("REPO", "End of day millis   = " + end);

        // Fetch from network
        Response<List<AppointmentDto>> resp = api.appointmentApi().getTodaysAppointments(clinic).execute();
        List<Appointment> mapped = new ArrayList<>();
        if (resp.isSuccessful() && resp.body() != null) {
            for (AppointmentDto dto : resp.body()) {
                Appointment a = map(dto);
                mapped.add(a);
                Log.d("REPO", "Mapped appointment: id=" + a.id +
                        " start=" + a.startTime +
                        " end=" + a.endTime +
                        " clinic=" + a.clinic +
                        " status=" + a.status);
            }
        } else {
            Log.w("REPO", "Network call failed or returned empty body");
        }

        // Cache to DB
        for (Appointment a : mapped) {
            try {
                dao.insert(a);
            } catch (Exception ignored) {
                dao.update(a);
            }
        }

        // Return from DB
        List<Appointment> dbList = dao.findBetweenOptionalClinic(start, end, clinic);
        Log.d("REPO-DB", "DB returned " + dbList.size() + " appointments for range " + start + " → " + end);
        Log.d("REPO", "==== END getTodaysAppointments() ====");
        return dbList;
    }

    public Appointment bookOrReschedule(Appointment appt) throws Exception {
        AppointmentDto dto = new AppointmentDto();
        dto.id = appt.id;
        dto.patientNhsNumber = appt.patientNhsNumber;
        dto.startTime = appt.startTime;
        dto.endTime = appt.endTime;
        dto.clinicianId = appt.clinicianId;
        dto.clinicianName = appt.clinicianName;
        dto.clinic = appt.clinic;
        dto.status = "BOOKED";

        Response<AppointmentDto> resp = api.appointmentApi().bookOrReschedule(dto).execute();
        if (resp.isSuccessful() && resp.body() != null) {
            Appointment saved = map(resp.body());
            if (saved.id == 0) saved.id = appt.id;

            if (appt.id == 0) {
                dao.insert(saved);
            } else {
                dao.update(saved);
            }
            return saved;
        } else {
            String error = "";
            if (resp.errorBody() != null) {
                error = resp.errorBody().string();
            }
            throw new IllegalStateException("Booking failed: HTTP " + resp.code() + " " + error);
        }

    }

    public List<Appointment> detectConflicts(long clinicianId, long start, long end) {
        return dao.getConflictingAppointments(clinicianId, start, end);
    }

    private Appointment map(AppointmentDto dto) {
        Appointment a = new Appointment();
        a.id = dto.id;
        a.patientNhsNumber = dto.patientNhsNumber;
        a.startTime = dto.startTime;
        a.endTime = dto.endTime;
        a.clinicianId = dto.clinicianId;
        a.clinicianName = dto.clinicianName;
        a.clinic = dto.clinic;
        a.status = dto.status;
        return a;
    }
}
