package com.example.hospimanagmenetapp.feature.appointments.ui;

import android.content.Context;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class DailyAppointmentScheduler {


    private static final String WORK_NAME = "DailyAppointmentWorker";

    public static void scheduleDailyAppointments(Context context) {

        // 1️⃣ Calculate initial delay until 9 AM
        Calendar now = Calendar.getInstance();
        Calendar nextRun = Calendar.getInstance();
        nextRun.set(Calendar.HOUR_OF_DAY, 9);
        nextRun.set(Calendar.MINUTE, 0);
        nextRun.set(Calendar.SECOND, 0);
        nextRun.set(Calendar.MILLISECOND, 0);

        if (now.after(nextRun)) {
            // If it's already past 9 AM today, schedule for tomorrow
            nextRun.add(Calendar.DAY_OF_MONTH, 1);
        }

        long initialDelay = nextRun.getTimeInMillis() - now.getTimeInMillis();

        // 2️⃣ Optional constraints (network not required in this case)
        Constraints constraints = new Constraints.Builder()
                .setRequiresBatteryNotLow(false)
                .setRequiresCharging(false)
                .build();

        // 3️⃣ Build the periodic work request (repeat every 24 hours)
        PeriodicWorkRequest dailyWork = new PeriodicWorkRequest.Builder(
                DailyAppointmentWorker.class, 24, TimeUnit.HOURS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setConstraints(constraints)
                .build();

        // 4️⃣ Enqueue unique periodic work
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.REPLACE,
                dailyWork
        );
    }


}
