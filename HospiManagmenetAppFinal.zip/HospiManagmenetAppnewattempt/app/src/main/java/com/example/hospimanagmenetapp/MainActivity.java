package com.example.hospimanagmenetapp;

import com.example.hospimanagmenetapp.encryption.hashing.Hash;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.ClinicalRecord;
import com.example.hospimanagmenetapp.feature.appointments.ui.DailyAppointmentScheduler;
import com.example.hospimanagmenetapp.feature.ehr.ui.PatientSummaryActivity;
import com.example.hospimanagmenetapp.ui.AdminLoginActivity;
import com.example.hospimanagmenetapp.ui.AdminPortalActivity;
import com.example.hospimanagmenetapp.ui.PatientRegistrationActivity;
import com.example.hospimanagmenetapp.util.SessionManager;

import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {


    private TextView tvWelcome;
    private Button btnPatientRegistration, btnAdminPortal, btnLogout, btnAppointments, btnRecords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind UI
        tvWelcome = findViewById(R.id.tvWelcome);
        btnPatientRegistration = findViewById(R.id.btnPatientRegistration);
        btnAdminPortal = findViewById(R.id.btnAdminPortal);
        btnLogout = findViewById(R.id.btnLogout);
        btnRecords = findViewById(R.id.btnRecords);
        btnAppointments = findViewById(R.id.btnAppointments);

        // Navigate to Appointment screen
        btnAppointments.setOnClickListener(v ->
                startActivity(new Intent(this,
                        com.example.hospimanagmenetapp.feature.appointments.ui.AppointmentActivity.class))
        );

        // Schedule daily slot generation
        DailyAppointmentScheduler.scheduleDailyAppointments(this);

        // Set header
        refreshHeader();

        // Patient registration
        btnPatientRegistration.setOnClickListener(v ->
                startActivity(new Intent(this, PatientRegistrationActivity.class))
        );

        // Admin login → Admin Portal
        btnAdminPortal.setOnClickListener(v ->
                startActivity(new Intent(this, AdminLoginActivity.class))
        );

        // Logout
        btnLogout.setOnClickListener(v -> {
            SessionManager.clear(this);
            refreshHeader();
        });

        // Records access
        btnRecords.setOnClickListener(v -> {
            String role = SessionManager.getCurrentRole(this);

            if ("ADMIN".equals(role)) {
                startActivity(new Intent(this, PatientSummaryActivity.class));
            } else {
                Toast.makeText(this,
                        "Admin privileges required to access patient records.",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, AdminLoginActivity.class));
            }
        });
    }

    private void refreshHeader() {
        String role = SessionManager.getCurrentRole(this);
        String email = SessionManager.getCurrentEmail(this);

        if (role == null || role.isEmpty()) {
            tvWelcome.setText("Welcome (not signed in)");
        } else {
            tvWelcome.setText("Signed in: " + email + " (" + role + ")");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshHeader();
    }


}
