package com.example.hospimanagmenetapp.data; // Package for data-layer classes

import androidx.room.Database;          // Room annotation to define the DB schema
import androidx.room.Room;              // Factory for creating Room databases
import androidx.room.RoomDatabase;      // Base class for Room databases
import android.content.Context;         // Needed to build the DB with an app Context

import com.example.hospimanagmenetapp.data.dao.PatientDao; // DAO for Patient operations
import com.example.hospimanagmenetapp.data.dao.StaffDao;   // DAO for Staff operations
import com.example.hospimanagmenetapp.data.entities.Patient; // Entity mapped to a table
import com.example.hospimanagmenetapp.data.entities.Staff;   // Entity mapped to a table

@Database(entities = {
        com.example.hospimanagmenetapp.data.entities.Patient.class,
        com.example.hospimanagmenetapp.data.entities.Staff.class,
        com.example.hospimanagmenetapp.data.entities.Appointment.class,
        com.example.hospimanagmenetapp.data.entities.ClinicalRecord.class,
        com.example.hospimanagmenetapp.data.entities.Vitals.class
}, version = 15, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE = null;
    public abstract com.example.hospimanagmenetapp.data.dao.PatientDao patientDao();
    public abstract com.example.hospimanagmenetapp.data.dao.StaffDao staffDao();
    public abstract com.example.hospimanagmenetapp.data.dao.AppointmentDao appointmentDao(); // NEW

    public abstract com.example.hospimanagmenetapp.data.dao.ClinicalRecordDao clinicalRecordDao();

    public abstract com.example.hospimanagmenetapp.data.dao.VitalsDao vitalsDao();

    // Thread-safe double-checked locking to get/create the singleton DB
    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) { // Fast path: already created?
            synchronized (AppDatabase.class) { // Serialise creation across threads
                if (INSTANCE == null) { // Second check inside the lock
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(), // Use app Context to avoid Activity leaks
                                    AppDatabase.class,               // The RoomDatabase subclass to create
                                    "hms_db"                         // On-device filename for the DB
                            )
                            .fallbackToDestructiveMigration()       // Wipes & rebuilds on version change if no migration (dev-friendly, data-loss risk)
                            .allowMainThreadQueries()
                            .build();                               // Build the database instance
                }
            }
        }
        return INSTANCE; // Return the shared database
    }
}