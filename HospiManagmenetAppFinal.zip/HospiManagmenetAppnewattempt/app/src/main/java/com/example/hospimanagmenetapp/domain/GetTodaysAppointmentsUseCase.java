package com.example.hospimanagmenetapp.domain;

import android.content.Context;
import android.util.Log;

import com.example.hospimanagmenetapp.data.entities.Appointment;
import com.example.hospimanagmenetapp.data.repo.AppointmentRepository;

import java.util.Calendar;
import java.util.List;

public class GetTodaysAppointmentsUseCase {

    private final AppointmentRepository repo;
    private static final String TAG = "USECASE";

    public GetTodaysAppointmentsUseCase(Context ctx) {
        this.repo = new AppointmentRepository(ctx);
    }

    public List<Appointment> execute(String clinic) throws Exception {

        Log.d(TAG, "Clinic passed in = [" + clinic + "]");

        // FIX: Use real current time, not buggy Calendar instance defaults
        long now = System.currentTimeMillis();

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);

        // Start of day
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        long start = cal.getTimeInMillis();

        // End of day
        cal.add(Calendar.DAY_OF_MONTH, 1);
        long end = cal.getTimeInMillis();

        Log.d(TAG, "Start of day millis = " + start);
        Log.d(TAG, "End of day millis = " + end);

        List<Appointment> list = repo.getTodaysAppointments(clinic, start, end);

        Log.d(TAG, "Appointments returned = " + list.size());

        return list;
    }
}
