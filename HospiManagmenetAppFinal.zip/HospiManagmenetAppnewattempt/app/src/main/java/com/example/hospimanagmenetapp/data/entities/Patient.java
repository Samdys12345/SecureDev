package com.example.hospimanagmenetapp.data.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "patients",
        indices = {@Index(value = {"nhsNumber"}, unique = true)}
)
public class Patient {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    public String nhsNumber;

    // Encrypted data fields
    public byte[] fullNameEnc;
    public byte[] dateOfBirthEnc;
    public byte[] phoneEnc;
    public byte[] emailEnc;

    public long createdAt;
    public long updatedAt;
}
