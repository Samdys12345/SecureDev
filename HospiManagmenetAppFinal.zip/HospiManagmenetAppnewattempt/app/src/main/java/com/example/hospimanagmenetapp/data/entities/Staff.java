package com.example.hospimanagmenetapp.data.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "staff",
        indices = {@Index(value = {"emailHash"}, unique = true)}
)
public class Staff {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    public byte[] email;

    @NonNull
    public String emailHash;  // SHA-256 hash of email for lookup

    @NonNull
    public byte[] fullName;

    public byte[] adminPin;

    public Role role;

    public enum Role {
        ADMIN,
        STAFF,
        CLINICIAN,
        RECEPTION,
    }
}
