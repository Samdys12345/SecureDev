package com.example.hospimanagmenetapp.network.dto;

public class PatientDto {
    public long id;

    public String nhsNumber;

    public String fullName;        // Patient’s full name (consider @NonNull if mandatory)
    public String dateOfBirth;     // ISO yyyy-MM-dd for simplicity; a TypeConverter to Date is cleaner
    public String phone;           // Contact number (normalised/validated in code)
    public String email;           // Contact email (basic pattern check in code/UI)

    public long createdAt;         // Unix epoch millis when the record was created
    public long updatedAt;


}
